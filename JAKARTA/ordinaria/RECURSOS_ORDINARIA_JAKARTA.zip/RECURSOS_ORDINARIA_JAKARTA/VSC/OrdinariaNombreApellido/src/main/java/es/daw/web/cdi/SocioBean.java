package es.daw.web.cdi;

import jakarta.enterprise.inject.Model;

@Model
public class SocioBean {

    private String nombre;
    private String email;
    private String telefono;
    private String libro;


    // PENDIENTE DE COMPLETAR

    
    
}
