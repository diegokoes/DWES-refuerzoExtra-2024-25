package es.daw.web.entities;


public class Prestamo {

    


    
    
}
