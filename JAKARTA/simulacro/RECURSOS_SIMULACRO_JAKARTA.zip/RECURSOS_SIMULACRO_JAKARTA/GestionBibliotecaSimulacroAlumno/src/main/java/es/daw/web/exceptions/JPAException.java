package es.daw.web.exceptions;

public class JPAException extends Exception{
    public JPAException(String message){
        super(message);
    }
}
