package es.daw.web.entities;


public class Autor {

    private Integer id;

    private String nombre;


}

