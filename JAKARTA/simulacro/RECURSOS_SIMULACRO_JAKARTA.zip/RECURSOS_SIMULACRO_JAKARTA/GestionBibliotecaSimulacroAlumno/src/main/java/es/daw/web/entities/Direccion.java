package es.daw.web.entities;

public class Direccion {

    private Integer id;
    private String calle;
    private String ciudad;
    private String codigoPostal;

    
}
