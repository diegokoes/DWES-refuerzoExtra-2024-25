package es.daw.demo.api_data_rest_estudiantes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiDataRestEstudiantesApplicationTests {

    @Test
    void contextLoads() {
    }

}
