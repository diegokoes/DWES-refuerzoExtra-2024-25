package es.daw.demo.api_data_rest_estudiantes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiDataRestEstudiantesApplication {

    public static void main(String[] args) {
        SpringApplication.run(ApiDataRestEstudiantesApplication.class, args);
    }

}
